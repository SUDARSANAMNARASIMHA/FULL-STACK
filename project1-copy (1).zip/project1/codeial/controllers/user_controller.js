const User = require('../models/users')

module.exports.profile = function(req,res){
    return res.end('<h1>User profile</h1>');
}
module.exports.userprofile = async function(req,res){
    try{
        
        if(req.cookies.user_id){
            
            const user = await User.findById(req.cookies.user_id);
            
            if(user){  
                return res.render('user_profile',{  
                    title:"title",
                    user:user  
                });
            }
            return res.redirect('sign-in')
        
        }else{
            console.log("in profilre");
            return res.redirect('sign-in')
        }
    }catch(err){
        console.log("error in details");
    }
    // return res.render('profile');
    // return res.end('<h1>in profile</h1>');
}
module.exports.sign_in = function(req,res){
    if(req.isAuthenticated()){
        return res.redirect('/');
    }
    return res.render('sign-in',{
        title:'sign-in'
    })
}

module.exports.sign_up= function(req,res){
    if(req.isAuthenticated()){
        return res.redirect('/');
    }
    return res.render('sign-up',{
        title:"sign-up"
    })
}

module.exports.create=async function(req,res){
    if(req.body.password!=req.body.confirmpassword){
        return res.redirect('back');
    }
   
   try{
        const user = await User.findOne({email:req.body.email});
        if(!user){
            // console.log("in");
            User.create(req.body);
            return res.redirect('sign-in');
        }
        return res.redirect('back');
   }catch(err){
        console.log('Error in signing up:', err);
        return res.status(500).send('Internal Server Error');
   }
}

// module.exports.createSession= async function(req,res){
//     console.log("innnnnnnn");
//     try{
//         const user = await User.findOne({email : req.body.email});
//         if(user){
//             if(user.password!=req.body.password)
//                 return res.redirect('back');

//             res.cookie('user_id',user.id);
//             return res.redirect('userprofile');
//             // return res.render('profile',{
//             //     title:"pro",
//             //     user:user
//             // })
//         }
//         return res.redirect('back');
//     }catch(err){
//         console.log("error in sign in");
//     }
// }

 module.exports.createSession= function(req,res){
    return res.redirect('/'); 
}
