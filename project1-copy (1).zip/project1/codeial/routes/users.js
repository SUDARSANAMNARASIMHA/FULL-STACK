const express = require('express');

const router = express.Router();

const passport = require('passport');

const user_controller = require('../controllers/user_controller');


router.get('/sign-up',user_controller.sign_up)
router.get('/sign-in',user_controller.sign_in)
router.post('/create',user_controller.create)
router.post('/createSession',passport.authenticate(
    'local',
    {failureRedirect :  '/users/sign-in'}
),user_controller.createSession);

module.exports=router;