const express = require('express');
const app = express();
const user_controller = require('../controllers/user_controller');
const userRoute = require('./users');
const passport = require('passport');``

app.get('/',passport.checkAuthentication, user_controller.profile);
app.get('/userprofile', user_controller.userprofile);
app.use('/users', userRoute);

module.exports = app;