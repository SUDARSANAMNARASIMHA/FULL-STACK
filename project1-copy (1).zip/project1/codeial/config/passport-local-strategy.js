const passport =require('passport')

const LocalStartegy = require('passport-local').Strategy;

const User = require('../models/users')
//developer need's to tell the passport to use
//LocalStartegy it will find the user in the database
//using email if user found then that will automatically
// stored in the cookie session by serializeUser 
passport.use(new LocalStartegy({
    usernameField: 'email'
},async  function(email, password, done) {
    try{
    const user=await User.findOne({ email: email });
         

        if (!user || user.password !== password) {
            console.log('invalid password or email');
            return done(null, false);
        }

        return done(null, user);
    }catch(err){
        console.log('error kin finding user');
            return done(err);
    }}
));
//serializeUser will store the user object data inthe session cookie in
//encripted format
passport.serializeUser(function(user,done){
    done(null,user.id);
});
//deserializeUser function is used to find the user in the database
//based on the id which is stored by the serializeUser in encripted format
passport.deserializeUser(async function(id,done){
    try{

        const user = await User.findById(id);
        return done(null,user);

    }catch(err){
        console.log('error kin finding user');
            return done(err);
    }

});

passport.checkAuthentication= function(req,res,next){
    if(req.isAuthenticated()){
        return next();
    }
    return res.redirect('./users/sign-in');
}

passport.setAuthenticatedUser = function(req,res,next){
    if(req.isAuthenticated()){
        res.locals.user = req.user;
    }
    next()
}

module.exports = passport;